/**
 * @author Michael
 */

$(document).ready(function(){
   var formValidate = $('#addForm');
   $("#addForm").validate();
});
